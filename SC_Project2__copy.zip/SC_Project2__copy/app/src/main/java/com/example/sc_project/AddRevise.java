package com.example.sc_project;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddRevise extends Activity
{
    public static final String NAME = "이름";

    Button g_o_btn;
    Button g_a_btn;
    Button s_o_btn;
    Button s_a_btn;
    Button con_btn;
    Button can_btn;
    InfoClass info;
    String g_Phonename, s_Phonename;
    String g_Phonenumber, s_Phonenumber;
    boolean flaggs;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        setContentView(R.layout.revise_item);
        super.onCreate(savedInstanceState);

        g_o_btn = (Button) findViewById(R.id.grind_who);
        g_a_btn = (Button) findViewById(R.id.grind_what);
        s_o_btn = (Button) findViewById(R.id.send_who);
        s_a_btn = (Button) findViewById(R.id.send_what);
        con_btn = (Button) findViewById(R.id.confirm);
        can_btn = (Button) findViewById(R.id.cancel);
        //-1은 임시 info를 의미한다.
        g_Phonenumber="초기화";
        info = new InfoClass(-1, g_o_btn.getText().toString(), g_a_btn.getText().toString(), s_o_btn.getText().toString(), s_a_btn.getText().toString());
        con_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent(v.getContext(), MainActivity.class);
                i.putExtra("info_go", g_Phonenumber);
                i.putExtra("info_ga", info.get_g_what().toString());
                i.putExtra("info_so", info.get_s_name().toString());
                i.putExtra("info_sa", info.get_s_what().toString());
                setResult(RESULT_OK, i);
                finish();
            }
        });
        can_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

        //누가 보냄?
        g_o_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
//                Toast.makeText(getApplication(), "수신 누구?", Toast.LENGTH_SHORT).show();
                if(!AddRevise.this.isFinishing()) {
                    final CharSequence[] items = {"기존 연락처", "번호 입력"};
                    final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(v.getContext());

                    //제목
                    alertDialogBuilder.setTitle("수신자 선택");
                    alertDialogBuilder.setItems(items, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(which == 0)      //기존 연락처
                            {
                                Intent intent = new Intent(Intent.ACTION_PICK);
                                intent.setData(ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                                startActivityForResult(intent, 0);
                            }
                            else    //번호 입력
                            {
                                AlertDialog.Builder alertnumberinput = new AlertDialog.Builder(v.getContext());

                                alertnumberinput.setTitle("번호입력");
                                alertnumberinput.setMessage("입력하세요!");

                                final EditText input = new EditText(v.getContext());
                                alertnumberinput.setView(input);

                                alertnumberinput.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        g_Phonename = input.getText().toString();
                                        g_Phonenumber = input.getText().toString();
                                        g_o_btn.setText(g_Phonename);
                                        info.set_g_name(g_Phonenumber);
                                    }
                                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //취소
                                    }
                                });
                                alertnumberinput.show();
                            }
                            flaggs = true;
                            dialog.dismiss();
                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }
            }
        });
        //무엇을 보냄?
        g_a_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
//                Toast.makeText(getApplication(), "수신 무엇?", Toast.LENGTH_SHORT).show();
                if(!AddRevise.this.isFinishing()) {
                    final CharSequence[] items = {"일반 메세지"};
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(v.getContext());

                    alertDialogBuilder.setTitle("받은 메세지 선택");   //제목
                    alertDialogBuilder.setItems(items, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(which == 0)      //일반 메세지
                            {
                                g_a_btn.setText("일반 메세지");

                            }
//                            else    //특정 단어의 메세지
//                            {
//                                g_a_btn.setText("특정 단어의 메세지");
//
//                            }
                            info.set_g_what(g_a_btn.getText().toString());
                            dialog.dismiss();
                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }
            }
        });
        //누구에게 보냄?
        s_o_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(final View v)
            {
//                Toast.makeText(getApplication(), "송신 누구?", Toast.LENGTH_SHORT).show();
                if(!AddRevise.this.isFinishing()) {
                    final CharSequence[] items = {"기존 연락처", "번호 입력", "카카오톡 : 나"};
                    final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(v.getContext());

                    //제목
                    alertDialogBuilder.setTitle("송신자 선택");
                    alertDialogBuilder.setItems(items, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(which == 0)      //기존 연락처
                            {
                                Intent intent = new Intent(Intent.ACTION_PICK);
                                intent.setData(ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                                startActivityForResult(intent, 1);
                            }
                            else if(which == 1)    //번호 입력
                            {
                                AlertDialog.Builder alertnumberinput = new AlertDialog.Builder(v.getContext());

                                alertnumberinput.setTitle("번호입력");
                                alertnumberinput.setMessage("입력하세요!");

                                final EditText input = new EditText(v.getContext());
                                alertnumberinput.setView(input);

                                alertnumberinput.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        s_Phonename = input.getText().toString();
                                        s_Phonenumber = input.getText().toString();
                                        s_Phonenumber = s_Phonenumber.replace("-", "");
                                        s_o_btn.setText(s_Phonename);
                                        info.set_s_name(s_Phonenumber);
                                    }
                                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //취소
                                    }
                                });

                                alertnumberinput.show();

                            }
                            else    //카카오톡
                            {
                                s_o_btn.setText("카카오톡 : 나");
                            }
                            info.set_s_name(s_o_btn.getText().toString());
                            flaggs = false;
                            dialog.dismiss();
                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }
            }
        });
        //무엇을 보냄?
        s_a_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
//                Toast.makeText(getApplication(), "송신 무엇?", Toast.LENGTH_SHORT).show();
                if(!AddRevise.this.isFinishing()) {
                    final CharSequence[] items = {"그 메세지"};
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(v.getContext());

                    alertDialogBuilder.setTitle("송신 메세지 선택");   //제목
                    alertDialogBuilder.setItems(items, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if(which == 0)      //일반 메세지
                            {
                                s_a_btn.setText("그 메세지");
                            }
//                            else    //특정 단어의 메세지
//                            {
//                                s_a_btn.setText("특정 메세지");
//                            }
                            info.set_s_what(s_a_btn.getText().toString());
                            dialog.dismiss();
                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if(requestCode == 0 && resultCode == RESULT_OK) {
            Cursor cursor = getContentResolver().query(data.getData(), new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);
            cursor.moveToFirst();
            g_Phonename = cursor.getString(0);
            g_Phonenumber = cursor.getString(1);
            g_Phonenumber = g_Phonenumber.replace("-", "");
            Toast.makeText(getApplicationContext(), g_Phonename+g_Phonenumber, Toast.LENGTH_SHORT).show();

            cursor.close();
            g_o_btn.setText(g_Phonename);
            info.set_g_name(g_Phonenumber);
            super.onActivityResult(requestCode, resultCode, data);
        }
        else if(requestCode == 1 && resultCode == RESULT_OK)
        {
            Cursor cursor = getContentResolver().query(data.getData(), new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);
            cursor.moveToFirst();
            s_Phonename = cursor.getString(0);
            s_Phonenumber = cursor.getString(1);
            s_Phonenumber = s_Phonenumber.replace("-", "");
            cursor.close();
            s_o_btn.setText(s_Phonename);
            info.set_s_name(s_Phonenumber);
            super.onActivityResult(requestCode, resultCode, data);
        }
    }


    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        super.onBackPressed();
    }
}
