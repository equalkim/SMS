package com.example.sc_project;

public class Constants
{
    //쓸 필요 없는것 같은디
    public static final int G_NAME = 0;
    public static final int G_WHAT = 1;
    public static final int S_NAME = 2;
    public static final int S_WHAT = 3;
}
