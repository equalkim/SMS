package com.example.sc_project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter
{
    //문자열 보관
    //LayoutInflater는 액티비티 위에 다른 액티비티를 띄울 수 있다.
    //ViewHolder는 많은 findbyid를 할 때 효율을 높힙니다.
    private LayoutInflater inf;
    private ArrayList<InfoClass> List;
    private ViewHolder holder;

    //생성자
    public CustomAdapter(Context c, ArrayList<InfoClass> array)
    {
        inf = LayoutInflater.from(c);
        List = array;
    }

    //현재 아이템 개수
    @Override
    public int getCount()
    {
        return List.size();
    }

    //현재 아이템 오브젝트, 상황에 맞게 변형 or 캐스팅
    @Override
    public Object getItem(int position)
    {
        return List.get(position);
    }

    //아이템 position ID
    @Override
    public long getItemId(int position)
    {
        return position;
    }

    //출력될 아이템 관리
    @Override
    public View getView(int position, View convertView, final ViewGroup parent)
    {
        final int pos = position;
        final Context context = parent.getContext();
        //리스트가 길어지는 경우 짤리는 아이템들을 converView가 null이됨
        if (convertView == null)
        {
            holder = new ViewHolder();
            //view가 null일경우 CustomLayout들고옴
            inf = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inf.inflate(R.layout.list_item, parent, false);

            holder.g_name = (TextView) convertView.findViewById(R.id.grind_who);
            holder.g_what = (TextView) convertView.findViewById(R.id.grind_what);
            holder.s_name = (TextView) convertView.findViewById(R.id.send_who);
            holder.s_what = (TextView) convertView.findViewById(R.id.send_what);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        //info생성 -> 포지션에 맞는 데이터!
        InfoClass info = List.get(pos);
        //List에 아이템이 String 입력
        holder.g_name.setText(info.get_g_name());
        holder.g_what.setText(info.get_g_what());
        holder.s_name.setText(info.get_s_name());
        holder.s_what.setText(info.get_s_what());

         return convertView;
    }
    //Getter && Setter
    public void setArrayList(ArrayList<InfoClass> array)
    {
        this.List = array;
    }
    public ArrayList<InfoClass> getArrayList()
    {
        return List;
    }

    //외부에서 아이템 추가 요청
    public void add(InfoClass info)
    {
        List.add(info);
    }

    //외부에서 아이템 삭제 요청
    public void remove(int _position)
    {
        List.remove(_position);
    }

    private class ViewHolder
    {
        TextView g_name;
        TextView g_what;
        TextView s_name;
        TextView s_what;
    }
}

