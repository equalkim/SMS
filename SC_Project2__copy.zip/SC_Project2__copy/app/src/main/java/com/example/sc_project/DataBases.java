package com.example.sc_project;

import android.provider.BaseColumns;

/*
 todoList
 */
public final class DataBases {

    public static final class CreateDB implements BaseColumns{
        public static final String GRIND_NAME = "g_name";
        public static final String GRIND_WHAT = "g_what";
        public static final String SEND_NAME = "s_name";
        public static final String SEND_WHAT = "s_what";
        public static final String _TABLENAME = "to_do_List";
        //DB 쿼리문 생성 코드
        public static final String _CREATE =
                "create table "+_TABLENAME+"("
                        +_ID+" integer primary key autoincrement, "
                        +GRIND_NAME+" text not null , "
                        +GRIND_WHAT+" text not null , "
                        +SEND_NAME+" text not null ,"
                        +SEND_WHAT+" text not null );";
    }
}

