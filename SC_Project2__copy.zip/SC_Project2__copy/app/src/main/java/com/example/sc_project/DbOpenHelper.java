package com.example.sc_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbOpenHelper {
    //SQLite와 DatabaseHelper를 이용한 DB관리
    private static final String DATABASE_NAME = "to_do_list.db";
    private static final int DATABASE_VERSION = 1;
    public static SQLiteDatabase DB;
    private DatabaseHelper DBHelper;
    private Context Ctx;

    private class DatabaseHelper extends SQLiteOpenHelper
    {
        //생성자
        public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version)
        {
            super(context, name, factory, version);
        }
        //DB를 처음 만들때 실행
        @Override
        public void onCreate(SQLiteDatabase db)
        {
            //execSQL은 SELECT를 제외한 대부분의 쿼리문을 실행시켜주는 메소드이다.
            db.execSQL(DataBases.CreateDB._CREATE);
        }

        //DB 업데이트
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
        {
            //업데이트 했는데, 기존 DB가 남아있으면 재생성
            db.execSQL("DROP TABLE IF EXISTS "+DataBases.CreateDB._TABLENAME);
            onCreate(db);
        }
    }

    //DbOpenHelper 생성자
    public DbOpenHelper(Context context)
    {
        this.Ctx = context;
    }

    public DbOpenHelper open() throws SQLException {
        DBHelper = new DatabaseHelper(Ctx, DATABASE_NAME, null, DATABASE_VERSION);
        //DB를 읽고 쓸 수 있는 권한 부여
        DB = DBHelper.getWritableDatabase();
        return this;
    }

    public void close()
    {
        DB.close();
    }

    //사용자가 입력한 값을 DB에 추가
    //insert는 long타입이다.
    //Column은 관계형 DB에서의 열을 뜻함.
    public long insertColumn(String g_name, String g_what, String s_name, String s_what)
    {
        ContentValues values = new ContentValues();
        values.put(DataBases.CreateDB.GRIND_NAME, g_name);
        values.put(DataBases.CreateDB.GRIND_WHAT, g_what);
        values.put(DataBases.CreateDB.SEND_NAME, s_name);
        values.put(DataBases.CreateDB.SEND_WHAT, s_what);
        return DB.insert(DataBases.CreateDB._TABLENAME, null, values);
    }

    //쿼리문들은 >0이면 실행

    //기존 DB 변경
    public boolean updateColumn(long id, String g_name, String g_what, String s_name, String s_what)
    {
        ContentValues values = new ContentValues();
        values.put(DataBases.CreateDB.GRIND_NAME, g_name);
        values.put(DataBases.CreateDB.GRIND_WHAT, g_what);
        values.put(DataBases.CreateDB.SEND_NAME, s_name);
        values.put(DataBases.CreateDB.SEND_WHAT, s_what);
        //update("테이블명", 값, "컬럼명 = '변경할 문자열'", null);
        return DB.update(DataBases.CreateDB._TABLENAME, values, "id="+id, null) > 0;
    }

    //id로 DB 삭제
    public boolean deleteColumn(long id)
    {
        return DB.delete(DataBases.CreateDB._TABLENAME, "_id=" + id, null) > 0;
    }

    //커서 전체를 선택
    public Cursor getAllColumns()
    {
        //query(테이블, 컬럼, 선택값, 선택값배열, 그룹, 조건절, 정렬)
        return DB.query(DataBases.CreateDB._TABLENAME, null, null, null, null, null, null);
    }

    //ID 컬럼 얻어오기
    public Cursor getColumn(long id)
    {
        Cursor c = DB.query(DataBases.CreateDB._TABLENAME, null, "_id="+id, null, null, null, null);
        //받아온 컬럼이 null이 아니고 0번째가 아닐경우 제일 처음으로 보냄
        if(c != null&& c.getCount() != 0) c.moveToFirst();
        return c;
    }

}
