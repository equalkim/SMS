package com.example.sc_project;


//데이터 클래스
//단순히 생성자와 Getter Setter만 있는 것.
public class InfoClass{

    public int _id;
    private String g_name;
    private String g_what;
    private String s_name;
    private String s_what;


    //기본생성자
    public InfoClass() {}

    //매개변수 생성자
    public InfoClass(int _id, String g_name, String g_what, String s_name, String s_what)
    {
        this._id = _id;
        this.g_name = g_name;
        this.g_what = g_what;
        this.s_name = s_name;
        this.s_what = s_what;
    }

    //Getter && Setter
    public int get_id() { return _id; }
    public String get_g_name() { return g_name; }
    public void set_g_name(String g_name) { this.g_name = g_name; }
    public String get_g_what() { return g_what; }
    public void set_g_what(String g_what) { this.g_what = g_what; }
    public String get_s_name() { return s_name; }
    public void set_s_name(String s_name) { this.s_name = s_name; }
    public String get_s_what() { return s_what; }
    public void set_s_what(String s_what) { this.s_what = s_what; }
}
