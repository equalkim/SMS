package com.example.sc_project;

import android.app.Activity;
import android.content.Intent;

import com.kakao.kakaotalk.callback.TalkResponseCallback;

/**
 * Created by 재원 on 2016-11-09.
 */
public class KakaoTalkMainActivity extends Activity {

}