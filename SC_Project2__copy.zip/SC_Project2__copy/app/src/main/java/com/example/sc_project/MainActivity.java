package com.example.sc_project;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.SQLException;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import com.kakao.kakaotalk.KakaoTalkService;
import com.kakao.kakaotalk.callback.TalkResponseCallback;
import com.kakao.network.ErrorResult;
import com.kakao.util.helper.log.Logger;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private GoogleApiClient client;

    private ListView List;                  //목록 생성
    private CustomAdapter adapter;   //연결해주는 어댑터 생성

    //DB 관련
    private static final String TAG = "MainActivity";
    private DbOpenHelper open;
    private Cursor cursor;
    private InfoClass info;
    private ArrayList<InfoClass> list;

    //메세지 수신
    BroadcastReceiver receiver = new SmsReceiver();

    public String SMS_Context;  //받은 메세지를 저장하는 장소
    public String SMS_Sender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startActivity(new Intent(this, LoginActivity.class));

        open = new DbOpenHelper(this);
        try {
            open.open();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        list = new ArrayList<InfoClass>();
        CursorToArray();

        //데이터베이스에 데이터 추가
        //add(new InfoClass("a", "b", "c", "d"));

        //값이 제대로 입력되었는가?
        for (InfoClass i : list) {
            Log.i(TAG, "ID = " + i._id);
            Log.i(TAG, "G_NAME = " + i.get_g_name());
            Log.i(TAG, "G_WHAT = " + i.get_g_what());
            Log.i(TAG, "S_NAME = " + i.get_s_name());
            Log.i(TAG, "S_WHAT = " + i.get_s_what());
        }


        //커스텀 어뎁터 생성
        adapter = new CustomAdapter(this, list);
        //xml의 layout과 연결!
        List = (ListView) findViewById(R.id.listiview);
        //어댑터 연결
        List.setAdapter(adapter);
        //터치 이벤트 추가
        //List.setOnItemClickListener(onClickListItem);
        List.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder alear_confirm = new AlertDialog.Builder(MainActivity.this);
                alear_confirm.setMessage("삭제하시겠습니까?").setCancelable(true).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        remove(position);
                        //YES
                    }
                });
                AlertDialog alert = alear_confirm.create();
                alert.show();
                return true;
            }
        });

        //메세지 수신
        IntentFilter intentFilter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
        registerReceiver(receiver, intentFilter);


        //▼ 기본 템플릿 설정, 건들이지 않는다.
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        //▲

        //▼ 추가
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, AddRevise.class);
                startActivityForResult(i, 1);
            }
        });
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            InfoClass InstantInfo = new InfoClass();
            InstantInfo.set_g_name(data.getStringExtra("info_go"));
            InstantInfo.set_g_what(data.getStringExtra("info_ga"));
            InstantInfo.set_s_name(data.getStringExtra("info_so"));
            InstantInfo.set_s_what(data.getStringExtra("info_sa"));
            add(InstantInfo);
        } else if (resultCode == RESULT_CANCELED) {
            Toast.makeText(getApplicationContext(), "입력을 취소합니다.", Toast.LENGTH_SHORT).show();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void CursorToArray() {
        cursor = null;
        //모든 컬럼
        cursor = open.getAllColumns();
        //몇개?
        Log.i(TAG, "Count = " + cursor.getCount());

        while (cursor.moveToNext()) {
            info = new InfoClass(
                    cursor.getInt(cursor.getColumnIndex("_id")),
                    cursor.getString(cursor.getColumnIndex("g_name")),
                    cursor.getString(cursor.getColumnIndex("g_what")),
                    cursor.getString(cursor.getColumnIndex("s_name")),
                    cursor.getString(cursor.getColumnIndex("s_what"))
            );
            //입력된 값을 가지고 있는 info를 list에 추가
            list.add(info);

        }
        //닫기
        cursor.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_revise) {
            Toast.makeText(getApplicationContext(), "수정은 해당 아이템을 삭제하고 +를 클릭하시면 됩니다!", Toast.LENGTH_SHORT).show();
            return true;
        }
        if (id == R.id.action_del) {
            Toast.makeText(getApplicationContext(), "삭제는 해당 아이템을 롱클릭하시면 됩니다!", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //액티비티 종료될때 나오는 메소드
    @Override
    protected void onDestroy() {
        open.close();
        super.onDestroy();
    }

    //DB 추가
    public void add(InfoClass info) {
        open.insertColumn(info.get_g_name(), info.get_g_what(), info.get_s_name(), info.get_s_what());
        list.add(info);
        Log.i(TAG, String.valueOf(info._id));
        adapter.setArrayList(list);
        adapter.notifyDataSetChanged();
    }

    //DB 삭제
    public void remove(int position) {
        Log.i(TAG, "position" + position);
        //position은 0부터 시작
        InfoClass removeInfo = list.get(position);
        Log.i(TAG, "id" + removeInfo.get_id());
        boolean result = open.deleteColumn(removeInfo.get_id());
//        boolean result = list.

        if (result) {
            list.remove(position);
            adapter.setArrayList(list);
            adapter.notifyDataSetChanged();
        } else {
            Toast.makeText(MainActivity.this, "삭제가 안되면 껏다 켜주세요!", Toast.LENGTH_SHORT).show();
        }
    }

    //메세지 수신 이벤트
    public class SmsReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Toast.makeText(getApplicationContext(), "메세지 도착!", Toast.LENGTH_SHORT).show();
            if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")) {
//                StringBuilder sms = new StringBuilder();    //내용 변경 가능, 멀티쓰레드에서 못씀
                Bundle bundle = intent.getExtras();

                if (bundle != null) {
                    Object[] messages = (Object[]) bundle.get("pdus");
                    SmsMessage[] smsMessages = new SmsMessage[messages.length];
                    for (int i = 0; i < messages.length; i++) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            String format = bundle.getString("format");
                            smsMessages[i] = SmsMessage.createFromPdu((byte[]) messages[i], format);
                        } else {
                            smsMessages[i] = SmsMessage.createFromPdu((byte[]) messages[i]);
                        }
                    }
                    SMS_Context = smsMessages[0].getMessageBody().toString();
                    SMS_Sender = smsMessages[0].getOriginatingAddress();
//                    Toast.makeText(getApplicationContext(), SMS_Sender + SMS_Context, Toast.LENGTH_SHORT).show();
                    CheckMessage();
                }
            }
        }
    }

    void CheckMessage() {
        cursor = null;
        //모든 컬럼
        cursor = open.getAllColumns();
        //몇개?

        while (cursor.moveToNext()) {
//            Toast.makeText(getApplicationContext(), "DB내용 : " + cursor.getString(cursor.getColumnIndex("g_name")) + " 보낸이 : " + SMS_Sender, Toast.LENGTH_SHORT).show();
            if (cursor.getString(cursor.getColumnIndex("g_name")).equals(SMS_Sender)) {
//                Toast.makeText(getApplicationContext(), "DB내용과 같아!", Toast.LENGTH_SHORT).show();
                //메세지를 보내라!
//                Toast.makeText(getApplicationContext(), "s_what? : " + cursor.getString(cursor.getColumnIndex("s_name")) + "카카오톡 : 나", Toast.LENGTH_SHORT).show();
                if (!(cursor.getString(cursor.getColumnIndex("s_name"))).equals("카카오톡 : 나")) {
                    Toast.makeText(getApplicationContext(), "SMS로!", Toast.LENGTH_SHORT).show();
                    //SMS로 메세지 보내라
                    sendSMS(cursor.getString(cursor.getColumnIndex("s_name")));
                } else {
                    Toast.makeText(getApplicationContext(), "카톡으로!", Toast.LENGTH_SHORT).show();
                    //카톡으로 메세지 보내라
                    requestSendMemo();
                }
            }
        }

        cursor.close();
    }

    void sendSMS(String s_number) {
        PendingIntent sentIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_SENT_ACTION"), 0);
        PendingIntent deliveredIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_DELIVERED_ACTION"), 0);

        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:    //전송 성공
                        Toast.makeText(getApplicationContext(), "전송 완료", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        // 전송 실패
                        Toast.makeText(getApplicationContext(), "전송 실패", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        // 서비스 지역 아님
                        Toast.makeText(getApplicationContext(), "서비스 지역이 아닙니다", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        // 무선 꺼짐
                        Toast.makeText(getApplicationContext(), "무선(Radio)가 꺼져있습니다", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        // PDU 실패
                        Toast.makeText(getApplicationContext(), "PDU Null", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }, new IntentFilter("SMS_SENT_ACTION"));
        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (getResultCode()) {
                    case Activity.RESULT_OK:
                        // 도착 완료
                        Toast.makeText(getApplicationContext(), "SMS 도착 완료", Toast.LENGTH_SHORT).show();
                        break;
                    case Activity.RESULT_CANCELED:
                        // 도착 안됨
                        Toast.makeText(getApplicationContext(), "SMS 도착 실패", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }, new IntentFilter("SMS_DELIVERED_ACTION"));
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(s_number, null, SMS_Context, sentIntent, deliveredIntent);
    }

    void requestSendMemo() {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("''yy년 MM월 dd일 E요일");
        KakaoTalkMessageBuilder builder = new KakaoTalkMessageBuilder();
        builder.addParam("MESSAGE", SMS_Context);
        builder.addParam("SENDER", SMS_Sender);
        builder.addParam("DATE", sdf.format(date));

        KakaoTalkService.requestSendMemo(new KakaoTalkResponseCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                Toast.makeText(getApplicationContext(), "나의 채팅방에 보내기 성공? " + result, Toast.LENGTH_SHORT).show();
            }
        }
        , "1937"
        , builder.build());
    }

    public class KakaoTalkMessageBuilder
    {
        public Map<String, String> messageParams = new HashMap<String, String>();

        public KakaoTalkMessageBuilder addParam(String key, String value) {
            messageParams.put("${" + key + "}", value);
            return this;
        }

        public Map<String, String> build() {
            return messageParams;
        }
    }

    private void redirectLoginActivity() {
        final Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private abstract class KakaoTalkResponseCallback<T> extends TalkResponseCallback<T> {
        @Override
        public void onNotKakaoTalkUser() {
            Logger.w("not a KakaoTalk user");
        }

        @Override
        public void onFailure(ErrorResult errorResult) {
            Logger.e("failure : " + errorResult);
        }

        @Override
        public void onSessionClosed(ErrorResult errorResult) {
            redirectLoginActivity();
        }

        @Override
        public void onNotSignedUp() {
//            redirectSignupActivity();
        }
    }

    @Override
    public void onStart()
    {
        super.onStart();

        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Main Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.sc_project/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop()
    {
        super.onStop();

        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Main Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.example.sc_project/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }
}
